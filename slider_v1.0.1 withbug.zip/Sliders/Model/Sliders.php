<?php

class Trenza_Sliders_Model_Sliders extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("sliders/sliders");

    }

}
	 