<?php   
class Trenza_Sliders_Block_Index extends Mage_Core_Block_Template{   





}