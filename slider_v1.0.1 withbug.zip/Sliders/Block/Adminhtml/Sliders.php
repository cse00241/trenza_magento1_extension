<?php


class Trenza_Sliders_Block_Adminhtml_Sliders extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_sliders";
	$this->_blockGroup = "sliders";
	$this->_headerText = Mage::helper("sliders")->__("Sliders Manager");
	$this->_addButtonLabel = Mage::helper("sliders")->__("Add New Item");
	parent::__construct();
	
	}

}