<?php
class Trenza_Sliders_Block_Adminhtml_Sliders_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("sliders_form", array("legend"=>Mage::helper("sliders")->__("Item information")));

				
						

						$fieldset->addField("title", "text", array(
						"label" => Mage::helper("sliders")->__("Title"),
						"name" => "title",
						));

						$fieldset->addField("position", "text", array(
						"label" => Mage::helper("sliders")->__("Position"),
						"name" => "position",
						));

						$fieldset->addField("content", "editor", array(
						"label" => Mage::helper("sliders")->__("Content"),
						"name" => "content",
				          'wysiwyg'   => true,
				          'required'  => false,
						));
						
						$fieldset->addField("link", "text", array(
						"label" => Mage::helper("sliders")->__("Link"),
						"name" => "link",
						));

						$fieldset->addField('status', 'select', array(
						'label'     => Mage::helper('sliders')->__('Status'),
						'values'   => Trenza_Sliders_Block_Adminhtml_Sliders_Grid::getValueArray2(),
						'name' => 'status',
						));
					
						

				if (Mage::getSingleton("adminhtml/session")->getSlidersData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getSlidersData());
					Mage::getSingleton("adminhtml/session")->setSlidersData(null);
				} 
				elseif(Mage::registry("sliders_data")) {
				    $form->setValues(Mage::registry("sliders_data")->getData());
				}
				return parent::_prepareForm();
		}
}
