<?php

class Trenza_Sliders_Model_System_Config_Animation
{
    public function toOptionArray()
    {
        return array(
            array('value' => 'true', 'label' => Mage::helper('adminhtml')->__('Yes')),
            array('value' => 'false', 'label' => Mage::helper('adminhtml')->__('No')),
        );
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
    public function toOptionArray()
    {
        return array(
            array('value' => 0, 'label' => Mage::helper('adminhtml')->__('Data1')),
            array('value' => 1, 'label' => Mage::helper('adminhtml')->__('Data2')),
            array('value' => 2, 'label' => Mage::helper('adminhtml')->__('Data3')),
        );
    }
	
    public function toArray()
    {
        return array(
            0 => Mage::helper('adminhtml')->__('Data1'),
            1 => Mage::helper('adminhtml')->__('Data2'),
            3 => Mage::helper('adminhtml')->__('Data3'),
        );
    }
	*/
}
