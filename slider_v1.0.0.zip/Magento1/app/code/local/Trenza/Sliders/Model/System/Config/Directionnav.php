<?php

class Trenza_Sliders_Model_System_Config_Directionnav
{
    public function toOptionArray()
    {
        return array(
            array('value' => 'true', 'label' => Mage::helper('adminhtml')->__('Yes')),
            array('value' => 'false', 'label' => Mage::helper('adminhtml')->__('No')),
        );
    }

}
