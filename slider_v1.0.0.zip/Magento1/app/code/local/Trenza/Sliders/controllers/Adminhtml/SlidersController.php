<?php

class Trenza_Sliders_Adminhtml_SlidersController extends Mage_Adminhtml_Controller_Action
{
		protected function _initAction()
		{
				$this->loadLayout()->_setActiveMenu("sliders/sliders")->_addBreadcrumb(Mage::helper("adminhtml")->__("Sliders  Manager"),Mage::helper("adminhtml")->__("Sliders Manager"));
				return $this;
		}
		public function indexAction() 
		{
			    $this->_title($this->__("Sliders"));
			    $this->_title($this->__("Manager Sliders"));

				$this->_initAction();
				$this->renderLayout();
		}
		public function editAction()
		{			    
			    $this->_title($this->__("Sliders"));
				$this->_title($this->__("Sliders"));
			    $this->_title($this->__("Edit Item"));
				
				$id = $this->getRequest()->getParam("id");
				$model = Mage::getModel("sliders/sliders")->load($id);
				if ($model->getId()) {
					Mage::register("sliders_data", $model);
					$this->loadLayout();
					$this->_setActiveMenu("sliders/sliders");
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Sliders Manager"), Mage::helper("adminhtml")->__("Sliders Manager"));
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Sliders Description"), Mage::helper("adminhtml")->__("Sliders Description"));
					$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
					$this->_addContent($this->getLayout()->createBlock("sliders/adminhtml_sliders_edit"))->_addLeft($this->getLayout()->createBlock("sliders/adminhtml_sliders_edit_tabs"));
					$this->renderLayout();
				} 
				else {
					Mage::getSingleton("adminhtml/session")->addError(Mage::helper("sliders")->__("Item does not exist."));
					$this->_redirect("*/*/");
				}
		}

		public function newAction()
		{

		$this->_title($this->__("Sliders"));
		$this->_title($this->__("Sliders"));
		$this->_title($this->__("New Item"));

        $id   = $this->getRequest()->getParam("id");
		$model  = Mage::getModel("sliders/sliders")->load($id);

		$data = Mage::getSingleton("adminhtml/session")->getFormData(true);
		if (!empty($data)) {
			$model->setData($data);
		}

		Mage::register("sliders_data", $model);

		$this->loadLayout();
		$this->_setActiveMenu("sliders/sliders");

		$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Sliders Manager"), Mage::helper("adminhtml")->__("Sliders Manager"));
		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Sliders Description"), Mage::helper("adminhtml")->__("Sliders Description"));


		$this->_addContent($this->getLayout()->createBlock("sliders/adminhtml_sliders_edit"))->_addLeft($this->getLayout()->createBlock("sliders/adminhtml_sliders_edit_tabs"));

		$this->renderLayout();

		}
		public function saveAction()
		{

			$post_data=$this->getRequest()->getPost();


				if ($post_data) {

					try {
						if(isset($_FILES['filename']['name']) && $_FILES['filename']['name'] != '') {
					try {	
						/* Starting upload */	
						$uploader = new Varien_File_Uploader('filename');
						
						// Any extention would work
		           		$uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
						$uploader->setAllowRenameFiles(false);
						
						// Set the file upload mode 
						// false -> get the file directly in the specified folder
						// true -> get the file in the product like folders 
						//	(file.jpg will go in something like /media/f/i/file.jpg)
						$uploader->setFilesDispersion(false);
								
						// We set media as the upload dir
						$path = Mage::getBaseDir('media') . DS . 'slider' . DS ;
						$uploader->save($path, $_FILES['filename']['name'] );
						
					} catch (Exception $e) {
			      
			        }
		        
			        //this way the name is saved in DB
		  			$post_data['filename'] = $_FILES['filename']['name'];
		  			echo $post_data['filename'] = $_FILES['filename']['name'];
	  				//exit();
				}
						
						$model = Mage::getModel("sliders/sliders")
						->addData($post_data)
						->setId($this->getRequest()->getParam("id"))
						->save();

						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Sliders was successfully saved"));
						Mage::getSingleton("adminhtml/session")->setSlidersData(false);

						if ($this->getRequest()->getParam("back")) {
							$this->_redirect("*/*/edit", array("id" => $model->getId()));
							return;
						}
						$this->_redirect("*/*/");
						return;
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						Mage::getSingleton("adminhtml/session")->setSlidersData($this->getRequest()->getPost());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					return;
					}

				}
				$this->_redirect("*/*/");
		}



		public function deleteAction()
		{
				if( $this->getRequest()->getParam("id") > 0 ) {
					try {
						$model = Mage::getModel("sliders/sliders");
						$model->setId($this->getRequest()->getParam("id"))->delete();
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
						$this->_redirect("*/*/");
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					}
				}
				$this->_redirect("*/*/");
		}

		
		public function massRemoveAction()
		{
			try {
				$ids = $this->getRequest()->getPost('sliders_ids', array());
				foreach ($ids as $id) {
                      $model = Mage::getModel("sliders/sliders");
					  $model->setId($id)->delete();
				}
				Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
			}
			catch (Exception $e) {
				Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
			}
			$this->_redirect('*/*/');
		}
			
		/**
		 * Export order grid to CSV format
		 */
		public function exportCsvAction()
		{
			$fileName   = 'sliders.csv';
			$grid       = $this->getLayout()->createBlock('sliders/adminhtml_sliders_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
		} 
		/**
		 *  Export order grid to Excel XML format
		 */
		public function exportExcelAction()
		{
			$fileName   = 'sliders.xml';
			$grid       = $this->getLayout()->createBlock('sliders/adminhtml_sliders_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
		}
}
