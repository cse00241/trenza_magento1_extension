<?php

class Trenza_Sliders_Block_Adminhtml_Sliders_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

		public function __construct()
		{
				parent::__construct();
				$this->setId("slidersGrid");
				$this->setDefaultSort("sliders_id");
				$this->setDefaultDir("DESC");
				$this->setSaveParametersInSession(true);
		}

		protected function _prepareCollection()
		{
				$collection = Mage::getModel("sliders/sliders")->getCollection();
				$this->setCollection($collection);
				return parent::_prepareCollection();
		}
		protected function _prepareColumns()
		{
				$this->addColumn("sliders_id", array(
				"header" => Mage::helper("sliders")->__("ID"),
				"align" =>"right",
				"width" => "50px",
			    "type" => "number",
				"index" => "sliders_id",
				));
				
                $this->addColumn("position", array(
				"header" => Mage::helper("sliders")->__("Sort"),
				"index" => "position",
				));

				$this->addColumn("title", array(
				"header" => Mage::helper("sliders")->__("Title"),
				"index" => "title",
				));

				$this->addColumn('filename', array(
		          'header'    => Mage::helper('sliders')->__('Image'),
		          'align'     =>'left',
		          'width'     => '200px',
		          'index'     => 'filename',
				  'renderer' => 'sliders/adminhtml_sliders_grid_renderer_image'
		      ));

				$this->addColumn('status', array(
				'header' => Mage::helper('sliders')->__('Status'),
				'index' => 'status',
				'type' => 'options',
				'options'=>Trenza_Sliders_Block_Adminhtml_Sliders_Grid::getOptionArray2(),				
				));
			$this->addColumn('action',
            array(
                'header'    =>  Mage::helper('sliders')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('sliders')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        	));
						
			$this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV')); 
			$this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

				return parent::_prepareColumns();
		}

		public function getRowUrl($row)
		{
			   return $this->getUrl("*/*/edit", array("id" => $row->getId()));
		}


		
		protected function _prepareMassaction()
		{
			$this->setMassactionIdField('sliders_id');
			$this->getMassactionBlock()->setFormFieldName('sliders_ids');
			$this->getMassactionBlock()->setUseSelectAll(true);
			$this->getMassactionBlock()->addItem('remove_sliders', array(
					 'label'=> Mage::helper('sliders')->__('Remove Sliders'),
					 'url'  => $this->getUrl('*/adminhtml_sliders/massRemove'),
					 'confirm' => Mage::helper('sliders')->__('Are you sure?')
				));
			return $this;
		}
			
		static public function getOptionArray2()
		{
            $data_array=array(); 
			$data_array[0]='Yes';
			$data_array[1]='No';
            return($data_array);
		}
		static public function getValueArray2()
		{
            $data_array=array();
			foreach(Trenza_Sliders_Block_Adminhtml_Sliders_Grid::getOptionArray2() as $k=>$v){
               $data_array[]=array('value'=>$k,'label'=>$v);		
			}
            return($data_array);

		}
		

}