<?php
class Trenza_Sliders_Block_Sliders extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getSliders()     
     { 
        if (!$this->hasData('sliders')) {
            $this->setData('sliders', Mage::registry('sliders'));
        }
        return $this->getData('sliders');
        
    }
	
	public function getSlidersCollection() {
		$collection = Mage::getModel('sliders/sliders')->getCollection()->addFieldToFilter('status',0)->setOrder('position');          
		return $collection;
	}
	
	public function isShowDescription(){
		return (int)Mage::getStoreConfig('sliders/general/show_description');
	}
	
	public function getListStyle(){
		return (int)Mage::getStoreConfig('sliders/general/list_style');
	}
}
