<?php
class Trenza_Sliders_Block_Adminhtml_Sliders_Edit_Tab_Form2 extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("sliders_form", array("legend"=>Mage::helper("sliders")->__("Item information")));
				$data = array();
				 if ( Mage::getSingleton('adminhtml/session')->getSlidersData() )
				{
					$data = Mage::getSingleton('adminhtml/session')->getSlidersData();
				} elseif ( Mage::registry('sliders_data') ) {
					$data = Mage::registry('sliders_data')->getData();
				}
				if ( !empty($data['filename']) ) {
					  $url = Mage::getBaseUrl('media') .'slider/' . $data['filename'];
			          $out = '<br/><center><a href="' . $url . '" target="_blank" id="imageurl">';
					  $out .= "<img src=" . $url . " width='250px' />";
					  $out .= '</a></center>';
				  }

			      $fieldset->addField('filename', 'file', array(
			          'label'     => Mage::helper('sliders')->__('Image File'),
			          'required'  => false,
			          'name'      => 'filename',
			          'note' => 'Image used for this silde '.$out,
				  ));		


					
						

				if (Mage::getSingleton("adminhtml/session")->getSlidersData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getSlidersData());
					Mage::getSingleton("adminhtml/session")->setSlidersData(null);
				} 
				elseif(Mage::registry("sliders_data")) {
				    $form->setValues(Mage::registry("sliders_data")->getData());
				}
				return parent::_prepareForm();
		}
}
