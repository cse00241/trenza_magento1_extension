<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
create table Sliders (sliders_id int not null auto_increment, title varchar(100),filename varchar(255) NOT NULL default '', content text(200), status varchar(100), position int(10),`link` varchar(255) NULL,primary key(sliders_id));
   
SQLTEXT;

$installer->run($sql);
 
$installer->endSetup();